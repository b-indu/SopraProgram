package com.binduyadav;

public class HomePage {
	public void getAllTaskById() {};
	public void creatTaskById() {};
	public void updateTaskById() {};
	public void deleteTaskById() {};
}
