package com.binduyadav;

public class Registration {
	
	public void registration()
	{
		
	};
	public void validation()
	{
		
	};

}
