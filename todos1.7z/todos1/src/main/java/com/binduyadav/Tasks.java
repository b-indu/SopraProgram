package com.binduyadav;

public class Tasks {

	String  name;
	String descreption;
	String  statuc;
	int  userId;
	String  Time;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescreption() {
		return descreption;
	}
	public void setDescreption(String descreption) {
		this.descreption = descreption;
	}
	public String getStatuc() {
		return statuc;
	}
	public void setStatuc(String statuc) {
		this.statuc = statuc;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	
}
