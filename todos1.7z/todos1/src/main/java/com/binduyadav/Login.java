package com.binduyadav;

public class Login {

	public void validation()
	{
		
	};
	public void login() {
		
	};
}
